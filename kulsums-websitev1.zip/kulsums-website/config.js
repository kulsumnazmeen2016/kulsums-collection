// Kulsums Collection: connection settings
// 1. In Supabase, open Project Settings, then API Keys (or Data API).
// 2. Paste your Project URL and your publishable key (it starts with sb_publishable_, or the older "anon public" key).
// 3. Save this file and upload it to GitHub next to index.html.
// These two values are safe to publish. Never put the secret or service_role key here.
window.KC_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT-ID.supabase.co",
  supabaseKey: "YOUR-PUBLISHABLE-KEY"
};
